n = int(input("Enter a number: "))
count = 0

i=2
while i<=n:
    if n%i==0:
        count = 1
        break
    else:
        count = 0

if count == 1:
    print("Prime number")
else:
    print("Not a prime number")
