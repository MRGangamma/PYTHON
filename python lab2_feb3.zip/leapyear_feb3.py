a=int(input("enetr a year"))
if a%4==0 or a%100==0:
    print("its a leap year")
else:
    print("its not a leap yaer")
