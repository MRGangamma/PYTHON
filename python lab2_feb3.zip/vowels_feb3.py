a=input("enter a character: ")
match a:
    case 'a' | 'e' | 'i' | 'o' | 'u':
        print("vowels")
    case _:
        print("constants")
