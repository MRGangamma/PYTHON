a=int(input("enetr a num"))
if a%2==0:
    print("its even")
else:
    print("its odd")
