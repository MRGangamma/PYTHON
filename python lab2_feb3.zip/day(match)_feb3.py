a=int(input("enter a num"))
match a:
    case a==1:
        print("MONDAY")
    case a==2:
        print("TUESDAY")
    case a==3:
        print("WEDNESDAY")
    case a==4:
        print("THURSDAY")
    case a==5:
        print("FRIDAY")
    case a==6:
        print("SATURDAY")
    case a==7:
        print("SUNDAY")
    case _:
        print("invalid option")
    
